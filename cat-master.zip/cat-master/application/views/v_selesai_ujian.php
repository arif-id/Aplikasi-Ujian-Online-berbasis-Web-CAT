<div class="row col-md-12">
  <div class="panel panel-info">
    <div class="panel-heading">Selesai ujian   </div>
    <div class="panel-body">
     <?php echo $data; ?>

     <a href="<?php echo base_url(); ?>adm/ikuti_ujian">Kembali</a>
          </div>
    </div>
  </div>
</div>
